Drawing set index — sample placeholder for procurement package.
